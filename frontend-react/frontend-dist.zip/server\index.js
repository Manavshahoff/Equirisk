import { w } from "./assets/worker-entry-CjEXjcQX.js";
import "node:events";
export {
  w as default
};
