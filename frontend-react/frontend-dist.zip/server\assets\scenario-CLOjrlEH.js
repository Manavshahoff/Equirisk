import { U as reactExports, L as jsxRuntimeExports } from "./server-CMrUY-aX.js";
import { e as createLucideIcon, a as Button, t as toast, i as getMarketQuote, o as scenarioRisk, B as BackendUnreachableError } from "./router-RLxpGFbz.js";
import { C as Card, b as CardHeader, c as CardTitle, a as CardContent, I as Input, L as LoaderCircle } from "./input-BHT9fjSy.js";
import { L as Label } from "./label-D_uZqoN1.js";
import { M as MetricCard, i as formatCurrency } from "./index-DtL9GV7S.js";
import { E as EditableTable, t as tradeColumns, a as newTrade, n as newMarketData, m as marketColumns, R as RiskBarChart, B as BaseVsShockedChart } from "./tradeColumns-DZAve4rg.js";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
import "util";
import "stream";
import "path";
import "http";
import "https";
import "url";
import "fs";
import "crypto";
import "net";
import "tls";
import "assert";
import "./worker-entry-CjEXjcQX.js";
import "node:events";
import "os";
import "events";
import "http2";
import "zlib";
const __iconNode = [
  [
    "path",
    {
      d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
      key: "1xq2db"
    }
  ]
];
const Zap = createLucideIcon("zap", __iconNode);
const initialScenario = {
  name: "Equity Down 5 Percent",
  spot_shock: -0.05,
  volatility_shock: 0.1,
  rate_shock: 0.01
};
function getNextTradeId(trades) {
  const maxNumber = trades.reduce((max, trade) => {
    const match = trade.trade_id.match(/^T(\d+)$/);
    if (!match) {
      return max;
    }
    const number = Number(match[1]);
    return number > max ? number : max;
  }, 0);
  const nextNumber = maxNumber + 1;
  return `T${String(nextNumber).padStart(3, "0")}`;
}
function ScenarioRiskPage() {
  const [trades, setTrades] = reactExports.useState([]);
  const [market, setMarket] = reactExports.useState([]);
  const [selT, setSelT] = reactExports.useState(/* @__PURE__ */ new Set());
  const [selM, setSelM] = reactExports.useState(/* @__PURE__ */ new Set());
  const [scenario, setScenario] = reactExports.useState(initialScenario);
  const [loading, setLoading] = reactExports.useState(false);
  const [result, setResult] = reactExports.useState(null);
  const submit = async () => {
    setLoading(true);
    try {
      const r = await scenarioRisk({
        trades,
        market_data: market,
        scenario
      });
      setResult(r);
      toast.success("Scenario complete", {
        description: scenario.name
      });
    } catch (e) {
      const msg = e instanceof BackendUnreachableError ? "FastAPI backend is not running on port 8000" : e.message;
      toast.error("Scenario failed", {
        description: msg
      });
    } finally {
      setLoading(false);
    }
  };
  const handleFetchScenarioMarketData = async () => {
    try {
      const uniqueSymbols = Array.from(new Set(trades.map((trade) => trade.symbol).filter(Boolean)));
      if (uniqueSymbols.length === 0) {
        toast.error("Please add at least one trade symbol first");
        return;
      }
      const quotes = await Promise.all(uniqueSymbols.map((symbol) => getMarketQuote(symbol)));
      const liveMarketData = quotes.map((quote) => ({
        symbol: quote.symbol,
        spot: quote.price,
        rate: 0.05,
        volatility: 0.2,
        as_of_date: quote.latest_trading_day
      }));
      setMarket(liveMarketData);
      toast.success("Live market data fetched successfully");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to fetch live market data");
    }
  };
  const tradeResults = result?.trade_results ?? result?.results ?? [];
  const pnlData = tradeResults.map((r) => ({
    symbol: r.symbol,
    value: r.pnl ?? 0
  }));
  const bvsData = tradeResults.map((r) => ({
    symbol: r.symbol,
    base: r.base_market_value ?? 0,
    shocked: r.shocked_market_value ?? 0
  }));
  const pnl = result?.portfolio_pnl;
  const pnlTone = pnl === void 0 ? "default" : pnl >= 0 ? "positive" : "negative";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-semibold tracking-tight", children: "Scenario Risk" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Shock the market and measure portfolio PnL impact across all trades." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Scenario Shocks" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs uppercase tracking-wider text-muted-foreground", children: "Scenario Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: scenario.name, onChange: (e) => setScenario({
            ...scenario,
            name: e.target.value
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs uppercase tracking-wider text-muted-foreground", children: "Spot Shock" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.01", value: scenario.spot_shock, onChange: (e) => setScenario({
            ...scenario,
            spot_shock: Number(e.target.value)
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground", children: "e.g. -0.05 for -5%" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs uppercase tracking-wider text-muted-foreground", children: "Volatility Shock" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.01", value: scenario.volatility_shock, onChange: (e) => setScenario({
            ...scenario,
            volatility_shock: Number(e.target.value)
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground", children: "Additive shift in vol" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs uppercase tracking-wider text-muted-foreground", children: "Rate Shock" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.001", value: scenario.rate_shock, onChange: (e) => setScenario({
            ...scenario,
            rate_shock: Number(e.target.value)
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground", children: "Additive shift in rate" })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Trades" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(EditableTable, { rows: trades, columns: tradeColumns, selected: selT, onSelectedChange: setSelT, onChange: setTrades, newRow: () => ({
        ...newTrade(),
        trade_id: getNextTradeId(trades)
      }), addLabel: "Add Trade Row" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Market Data" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "secondary", onClick: handleFetchScenarioMarketData, children: "Fetch Live Market Data" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(EditableTable, { rows: market, columns: marketColumns, selected: selM, onSelectedChange: setSelM, onChange: setMarket, newRow: newMarketData, addLabel: "Add Market Row" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: submit, disabled: loading, className: "gap-2 min-w-48", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
      " Running scenario…"
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "h-4 w-4" }),
      " Run Scenario"
    ] }) }) }),
    result && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Scenario", value: result.scenario_name ?? scenario.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Base Portfolio Value", value: formatCurrency(result.base_portfolio_value) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Shocked Portfolio Value", value: formatCurrency(result.shocked_portfolio_value), tone: "accent" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Portfolio PnL", value: formatCurrency(pnl), tone: pnlTone })
      ] }),
      tradeResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Trade-Level Scenario Results" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { className: "text-left", children: ["Trade ID", "Symbol", "Base MV", "Shocked MV", "PnL"].map((h) => /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-3 py-2 font-medium text-muted-foreground uppercase tracking-wider", children: h }, h)) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "tabular-nums", children: tradeResults.map((r) => {
              const p = r.pnl ?? 0;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-border hover:bg-secondary/20", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2 font-medium", children: r.trade_id }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: r.symbol ?? "—" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatCurrency(r.base_market_value) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatCurrency(r.shocked_market_value) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `px-3 py-2 font-medium ${p >= 0 ? "text-positive" : "text-negative"}`, children: formatCurrency(r.pnl) })
              ] }, r.trade_id);
            }) })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RiskBarChart, { title: "PnL by Trade", data: pnlData, signed: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(BaseVsShockedChart, { title: "Base vs Shocked Market Value", data: bvsData })
        ] })
      ] })
    ] })
  ] });
}
export {
  ScenarioRiskPage as component
};
