import { U as reactExports, L as jsxRuntimeExports } from "./server-CMrUY-aX.js";
import { e as createLucideIcon, f as createSlot, b as cn, a as Button, t as toast, i as getMarketQuote, p as priceTrade, B as BackendUnreachableError } from "./router-RLxpGFbz.js";
import { C as Card, b as CardHeader, c as CardTitle, a as CardContent, I as Input, L as LoaderCircle } from "./input-BHT9fjSy.js";
import { L as Label } from "./label-D_uZqoN1.js";
import { S as Select, e as SelectTrigger, f as SelectValue, c as SelectContent, d as SelectItem, M as MetricCard, j as formatNumber, i as formatCurrency } from "./index-DtL9GV7S.js";
import { J as JsonViewer } from "./JsonViewer-Bqj_hTC-.js";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
import "util";
import "stream";
import "path";
import "http";
import "https";
import "url";
import "fs";
import "crypto";
import "net";
import "tls";
import "assert";
import "./worker-entry-CjEXjcQX.js";
import "node:events";
import "os";
import "events";
import "http2";
import "zlib";
const __iconNode = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
];
const Sparkles = createLucideIcon("sparkles", __iconNode);
var NODES = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
];
var Primitive = NODES.reduce((primitive, node) => {
  const Slot = createSlot(`Primitive.${node}`);
  const Node = reactExports.forwardRef((props, forwardedRef) => {
    const { asChild, ...primitiveProps } = props;
    const Comp = asChild ? Slot : node;
    if (typeof window !== "undefined") {
      window[/* @__PURE__ */ Symbol.for("radix-ui")] = true;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { ...primitiveProps, ref: forwardedRef });
  });
  Node.displayName = `Primitive.${node}`;
  return { ...primitive, [node]: Node };
}, {});
var NAME = "Separator";
var DEFAULT_ORIENTATION = "horizontal";
var ORIENTATIONS = ["horizontal", "vertical"];
var Separator$1 = reactExports.forwardRef((props, forwardedRef) => {
  const { decorative, orientation: orientationProp = DEFAULT_ORIENTATION, ...domProps } = props;
  const orientation = isValidOrientation(orientationProp) ? orientationProp : DEFAULT_ORIENTATION;
  const ariaOrientation = orientation === "vertical" ? orientation : void 0;
  const semanticProps = decorative ? { role: "none" } : { "aria-orientation": ariaOrientation, role: "separator" };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Primitive.div,
    {
      "data-orientation": orientation,
      ...semanticProps,
      ...domProps,
      ref: forwardedRef
    }
  );
});
Separator$1.displayName = NAME;
function isValidOrientation(orientation) {
  return ORIENTATIONS.includes(orientation);
}
var Root = Separator$1;
const Separator = reactExports.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Root,
  {
    ref,
    decorative,
    orientation,
    className: cn(
      "shrink-0 bg-border",
      orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
      className
    ),
    ...props
  }
));
Separator.displayName = Root.displayName;
const initial = {
  trade_id: "T001",
  book: "EQD",
  symbol: "AAPL",
  product_type: "european_option",
  option_type: "call",
  quantity: 100,
  strike: 105,
  expiry: "2027-05-20",
  pricing_model: "black_scholes",
  spot: 100,
  rate: 0.05,
  volatility: 0.2,
  as_of_date: "2026-05-20"
};
function Field({
  label,
  children,
  hint
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs font-medium text-muted-foreground uppercase tracking-wider", children: label }),
    children,
    hint && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground", children: hint })
  ] });
}
function SingleTradePricingPage() {
  const [form, setForm] = reactExports.useState(initial);
  const [loading, setLoading] = reactExports.useState(false);
  const [result, setResult] = reactExports.useState(null);
  const set = (k, v) => setForm((f) => ({
    ...f,
    [k]: v
  }));
  const submit = async () => {
    setLoading(true);
    try {
      const r = await priceTrade(form);
      setResult(r);
      toast.success("Trade priced", {
        description: `Trade ${form.trade_id} priced successfully`
      });
    } catch (e) {
      const msg = e instanceof BackendUnreachableError ? "FastAPI backend is not running on port 8000" : e.message;
      toast.error("Pricing failed", {
        description: msg
      });
    } finally {
      setLoading(false);
    }
  };
  const handleFetchLiveSpot = async () => {
    if (!form.symbol) {
      toast.error("Please enter a symbol first");
      return;
    }
    try {
      const quote = await getMarketQuote(form.symbol);
      set("spot", quote.price);
      if (quote.latest_trading_day) {
        set("as_of_date", quote.latest_trading_day);
      }
      toast.success(`Fetched latest spot for ${quote.symbol}`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to fetch market data");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-semibold tracking-tight", children: "Single Trade Pricing" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Price a single equity derivative trade and inspect Greeks under the chosen pricing model." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80 shadow-[var(--shadow-card)]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Trade & Market Inputs" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3", children: "Trade" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Trade ID", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.trade_id, onChange: (e) => set("trade_id", e.target.value) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Book", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.book, onChange: (e) => set("book", e.target.value) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Symbol", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.symbol, onChange: (e) => set("symbol", e.target.value) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Product Type", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.product_type, onValueChange: (v) => set("product_type", v), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "european_option", children: "European Option" }) })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Option Type", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.option_type, onValueChange: (v) => set("option_type", v), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "call", children: "Call" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "put", children: "Put" })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Quantity", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: form.quantity, onChange: (e) => set("quantity", Number(e.target.value)) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Strike", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: form.strike, onChange: (e) => set("strike", Number(e.target.value)) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Expiry", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", value: form.expiry, onChange: (e) => set("expiry", e.target.value) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Pricing Model", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.pricing_model, onValueChange: (v) => set("pricing_model", v), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "black_scholes", children: "Black-Scholes" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "monte_carlo", children: "Monte Carlo" }) })
            ] }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3", children: "Market Data" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Spot", hint: "Current underlying price", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: form.spot, onChange: (e) => set("spot", Number(e.target.value)) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "secondary", onClick: handleFetchLiveSpot, className: "whitespace-nowrap", children: "Fetch Live" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Rate", hint: "Risk-free rate (decimal)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.001", value: form.rate, onChange: (e) => set("rate", Number(e.target.value)) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Volatility", hint: "Annualized vol (decimal)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.01", value: form.volatility, onChange: (e) => set("volatility", Number(e.target.value)) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "As Of Date", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", value: form.as_of_date, onChange: (e) => set("as_of_date", e.target.value) }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: submit, disabled: loading, className: "gap-2 min-w-40", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
          " Pricing…"
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
          " Price Trade"
        ] }) }) })
      ] })
    ] }),
    result && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-medium text-muted-foreground uppercase tracking-wider", children: "Pricing Result" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Unit Price", value: formatNumber(result.unit_price, 4) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Market Value", value: formatCurrency(result.market_value), tone: "accent" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Delta", value: formatNumber(result.delta, 4) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Gamma", value: formatNumber(result.gamma, 6) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Vega", value: formatNumber(result.vega, 4) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Theta", value: formatNumber(result.theta, 4) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Rho", value: formatNumber(result.rho, 4) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(JsonViewer, { data: result })
    ] })
  ] });
}
export {
  SingleTradePricingPage as component
};
