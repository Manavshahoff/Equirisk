import { U as reactExports, L as jsxRuntimeExports } from "./server-CMrUY-aX.js";
import { e as createLucideIcon, a as Button, j as getMyTrades, t as toast, h as deleteMyTradeByTradeId, i as getMarketQuote, s as saveMyTrade, n as runRisk, B as BackendUnreachableError } from "./router-RLxpGFbz.js";
import { C as Card, b as CardHeader, c as CardTitle, a as CardContent, L as LoaderCircle } from "./input-BHT9fjSy.js";
import { M as MetricCard, i as formatCurrency, j as formatNumber } from "./index-DtL9GV7S.js";
import { E as EditableTable, t as tradeColumns, a as newTrade, n as newMarketData, m as marketColumns, R as RiskBarChart } from "./tradeColumns-DZAve4rg.js";
import { J as JsonViewer } from "./JsonViewer-Bqj_hTC-.js";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
import "util";
import "stream";
import "path";
import "http";
import "https";
import "url";
import "fs";
import "crypto";
import "net";
import "tls";
import "assert";
import "./worker-entry-CjEXjcQX.js";
import "node:events";
import "os";
import "events";
import "http2";
import "zlib";
const __iconNode$2 = [
  ["path", { d: "M12 15V3", key: "m9g1x1" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }]
];
const Download = createLucideIcon("download", __iconNode$2);
const __iconNode$1 = [
  [
    "path",
    {
      d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
      key: "10ikf1"
    }
  ]
];
const Play = createLucideIcon("play", __iconNode$1);
const __iconNode = [
  [
    "path",
    {
      d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
      key: "1c8476"
    }
  ],
  ["path", { d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7", key: "1ydtos" }],
  ["path", { d: "M7 3v4a1 1 0 0 0 1 1h7", key: "t51u73" }]
];
const Save = createLucideIcon("save", __iconNode);
function downloadCSV(rows) {
  if (rows.length === 0) return;
  const headers = Array.from(new Set(rows.flatMap((r) => Object.keys(r))));
  const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => {
    const v = r[h];
    if (v === null || v === void 0) return "";
    const s = String(v).replaceAll('"', '""');
    return /[",\n]/.test(s) ? `"${s}"` : s;
  }).join(","))].join("\n");
  const blob = new Blob([csv], {
    type: "text/csv"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `portfolio-risk-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
function getNextTradeId(trades) {
  const maxNumber = trades.reduce((max, trade) => {
    const match = trade.trade_id.match(/^T(\d+)$/);
    if (!match) {
      return max;
    }
    const number = Number(match[1]);
    return number > max ? number : max;
  }, 0);
  const nextNumber = maxNumber + 1;
  return `T${String(nextNumber).padStart(3, "0")}`;
}
function uniqueTradesByTradeId(trades) {
  const map = /* @__PURE__ */ new Map();
  for (const trade of trades) {
    map.set(trade.trade_id, trade);
  }
  return Array.from(map.values()).sort((a, b) => a.trade_id.localeCompare(b.trade_id));
}
function PortfolioRiskPage() {
  const [trades, setTrades] = reactExports.useState([]);
  const [market, setMarket] = reactExports.useState([]);
  const [selectedT, setSelectedT] = reactExports.useState(/* @__PURE__ */ new Set());
  const [selectedM, setSelectedM] = reactExports.useState(/* @__PURE__ */ new Set());
  const [loading, setLoading] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  const [result, setResult] = reactExports.useState(null);
  reactExports.useEffect(() => {
    const loadSavedTrades = async () => {
      const token = localStorage.getItem("equirisk_token");
      if (!token) {
        return;
      }
      try {
        const savedTrades = await getMyTrades();
        if (savedTrades.length > 0) {
          setTrades(uniqueTradesByTradeId(savedTrades));
          toast.success("Loaded your saved trades");
        }
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Failed to load saved trades");
      }
    };
    loadSavedTrades();
  }, []);
  const saveCurrentPortfolio = async () => {
    const token = localStorage.getItem("equirisk_token");
    if (!token) {
      toast.error("Please login first to save your portfolio");
      return;
    }
    setSaving(true);
    try {
      await Promise.all(trades.map((trade) => saveMyTrade(trade)));
      toast.success("Portfolio saved successfully");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save portfolio");
    } finally {
      setSaving(false);
    }
  };
  const removeSelectedTrades = async () => {
    const selectedIndexes = Array.from(selectedT);
    if (selectedIndexes.length === 0) {
      toast.error("Please select at least one trade to remove");
      return;
    }
    const selectedTrades = selectedIndexes.map((index) => trades[index]).filter(Boolean);
    const token = localStorage.getItem("equirisk_token");
    try {
      if (token) {
        await Promise.all(selectedTrades.map((trade) => deleteMyTradeByTradeId(trade.trade_id)));
      }
      setTrades((currentTrades) => currentTrades.filter((_, index) => !selectedT.has(index)));
      setSelectedT(/* @__PURE__ */ new Set());
      toast.success(token ? "Selected trades removed from saved portfolio" : "Selected trades removed from table");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to remove selected trades");
    }
  };
  const submit = async () => {
    setLoading(true);
    try {
      const r = await runRisk({
        trades,
        market_data: market
      });
      setResult(r);
      toast.success("Portfolio risk run complete", {
        description: `${r.priced_trades ?? r.trade_results?.length ?? 0} trades priced`
      });
    } catch (e) {
      const msg = e instanceof BackendUnreachableError ? "FastAPI backend is not running on port 8000" : e.message;
      toast.error("Risk run failed", {
        description: msg
      });
    } finally {
      setLoading(false);
    }
  };
  const handleFetchPortfolioMarketData = async () => {
    try {
      const uniqueSymbols = Array.from(new Set(trades.map((trade) => trade.symbol).filter(Boolean)));
      if (uniqueSymbols.length === 0) {
        toast.error("Please add at least one trade symbol first");
        return;
      }
      const quotes = await Promise.all(uniqueSymbols.map((symbol) => getMarketQuote(symbol)));
      const liveMarketData = quotes.map((quote) => ({
        symbol: quote.symbol,
        spot: quote.price,
        rate: 0.05,
        volatility: 0.2,
        as_of_date: quote.latest_trading_day
      }));
      setMarket(liveMarketData);
      toast.success("Live market data fetched successfully");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to fetch live market data");
    }
  };
  const tradeResults = result?.trade_results ?? result?.results ?? [];
  const chartData = tradeResults.map((r) => ({
    symbol: r.symbol,
    market_value: r.market_value ?? 0,
    delta: r.delta ?? 0,
    vega: r.vega ?? 0,
    theta: r.theta ?? 0
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-semibold tracking-tight", children: "Portfolio Risk" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Compute market value and Greeks across a portfolio of equity option trades." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Trades" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(EditableTable, { rows: trades, columns: tradeColumns, selected: selectedT, onSelectedChange: setSelectedT, onChange: setTrades, newRow: () => ({
        ...newTrade(),
        trade_id: getNextTradeId(trades)
      }), addLabel: "Add Trade Row", onRemoveSelected: removeSelectedTrades }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Market Data" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "secondary", onClick: handleFetchPortfolioMarketData, children: "Fetch Live Market Data" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(EditableTable, { rows: market, columns: marketColumns, selected: selectedM, onSelectedChange: setSelectedM, onChange: setMarket, newRow: newMarketData, addLabel: "Add Market Row" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3 justify-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "secondary", onClick: saveCurrentPortfolio, disabled: saving, className: "gap-2", children: saving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
        " Saving…"
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
        " Save Portfolio"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", onClick: () => downloadCSV(tradeResults), disabled: tradeResults.length === 0, className: "gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
        " Download Results CSV"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: submit, disabled: loading, className: "gap-2 min-w-48", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
        " Running risk…"
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "h-4 w-4" }),
        " Run Portfolio Risk"
      ] }) })
    ] }),
    result && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3", children: [
          "Portfolio Summary",
          result.run_id && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-muted-foreground/70 normal-case", children: [
            "· Run ID ",
            result.run_id
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Trades", value: result.total_trades ?? tradeResults.length }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Priced", value: result.priced_trades ?? "—", tone: "positive" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Failed", value: result.failed_trades ?? 0, tone: (result.failed_trades ?? 0) > 0 ? "negative" : "default" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Market Value", value: formatCurrency(result.total_market_value), tone: "accent" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Delta", value: formatNumber(result.total_delta, 4) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Gamma", value: formatNumber(result.total_gamma, 6) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Vega", value: formatNumber(result.total_vega, 4) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Theta", value: formatNumber(result.total_theta, 4) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(MetricCard, { label: "Total Rho", value: formatNumber(result.total_rho, 4) })
        ] })
      ] }),
      tradeResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-card/80 border-border/80", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Trade-Level Results" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { className: "text-left", children: ["Trade ID", "Symbol", "Unit Price", "Market Value", "Delta", "Gamma", "Vega", "Theta", "Rho", "Status"].map((h) => /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-3 py-2 font-medium text-muted-foreground uppercase tracking-wider", children: h }, h)) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "tabular-nums", children: tradeResults.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-border hover:bg-secondary/20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2 font-medium", children: r.trade_id }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: r.symbol ?? "—" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatNumber(r.unit_price, 4) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatCurrency(r.market_value) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatNumber(r.delta, 4) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatNumber(r.gamma, 6) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatNumber(r.vega, 4) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatNumber(r.theta, 4) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: formatNumber(r.rho, 4) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: r.error ? "text-negative" : "text-positive", children: r.error ? "Failed" : r.status ?? "OK" }) })
            ] }, r.trade_id)) })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RiskBarChart, { title: "Market Value by Trade", data: chartData.map((d) => ({
            symbol: d.symbol,
            value: d.market_value
          })), colorVar: "var(--chart-1)", signed: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(RiskBarChart, { title: "Delta by Trade", data: chartData.map((d) => ({
            symbol: d.symbol,
            value: d.delta
          })), signed: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(RiskBarChart, { title: "Vega by Trade", data: chartData.map((d) => ({
            symbol: d.symbol,
            value: d.vega
          })), colorVar: "var(--chart-4)", signed: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(RiskBarChart, { title: "Theta by Trade", data: chartData.map((d) => ({
            symbol: d.symbol,
            value: d.theta
          })), signed: true })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(JsonViewer, { data: result })
    ] })
  ] });
}
export {
  PortfolioRiskPage as component
};
